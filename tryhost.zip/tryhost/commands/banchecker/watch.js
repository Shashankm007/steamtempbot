const SteamAPI = require('steamapi');
const fs = require("fs");
const steam = new SteamAPI('B5C1ECC7CD233987368DA4157C7806EB');
const regex = RegExp('(?:https?:\/\/)?steamcommunity\.com\/(?:profiles|id)\/[a-zA-Z0-9_-]+');

// CUSTOM
var {
    unbannedP,
    announceP,
    watchP
} = require('./db/path.json');

module.exports = {
    name: "watch",
    category: "banchecker",
    description: "Adds steam account to watchlist and notifies when the account gets banned.",
    run: async(client, message, args) => {
        var i = 0;
        while (args[i]) {
            sid = args[i];
            i++;
            if (!sid.length) {
                return message.channel.send(`[ ${message.author} ] You didn't provide any arguments!`);
            } else {
                if (regex.test(sid)) {
                    steam.resolve(`${sid}`).then(id => {
                        message.channel.send(`[ ${message.author} ] Profile added to watchlist: ${id} \n You will be notified when the player gets banned. \n Kindly allow direct messages from this server. `);
                        temp = JSON.stringify({
                            user: `${message.author}`,
                            steamurl: id
                        });
                        console.log(temp);
                        fs.appendFile(watchP, temp + " \n", (err) => {
                            if (err) console.error(err)
                        });
                    }, reason => {
                        message.channel.send(`[ ${message.author} ] Please enter a valid profile link.`);
                    });
                } else {
                    message.channel.send(`[ ${message.author} ] Please enter a valid profile link.`);
                }
            }
        }
    }
}