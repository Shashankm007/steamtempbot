const {
    Client,
    MessageEmbed
} = require("discord.js");

let cpuStat = require("cpu-stat")

const client = new Client({
    disableEveryone: true
});

module.exports = {
    name: "botinfo",
    category: "info",
    description: "Sends detailed info about the client",
    run: async (client, message, args) => {
        cpuStat.usagePercent(function(err, percent, seconds) {
            if (err) {
                return console.log(err);
            }

            var totalCores = cpuStat.totalCores();
            const embedStats = new MessageEmbed()
                .setAuthor(client.user.username)
                .setTitle("**Stats:**")
                .setColor("#94a5f7")
                .setThumbnail(`${client.user.displayAvatarURL({ format: "png", dynamic: true })}`)
                .addField("\u200B", `\u200B`)
                .addField("Uptime ", `${client.uptime} ms`, true)
                .addField("API Latency", `${(client.ws.ping)}ms`, true)
                .addField("\u200B", `\u200B`)
                .addField("Users", `${client.users.cache.size}`, true)
                .addField("Servers", `${client.guilds.cache.size}`, true)
                .addField("Channels ", `${client.channels.cache.size}`, true)
                .addField("\u200B", `\u200B`)
                .addField("Total Cores", totalCores, true)
                .addField("CPU Usage", `${percent.toFixed(2)}%`, true)
                .setFooter("Twitter: @znixhook and @noobmaster007");
            message.channel.send(embedStats)
        });
    }
}